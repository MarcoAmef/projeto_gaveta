package com.example.chatboa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
